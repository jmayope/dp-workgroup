import java.util.ArrayList;
import java.util.List;


// 1. COMPONENT (Interfaz común para productos, kits y decoradores de servicios)
public interface ArticuloVenta {
    String descripcion();
    double precio();
    void mostrar(String sangria);
}

// 2. LEAF (Producto Simple / Hoja)
class ProductoSimple implements ArticuloVenta {
    private final String nombre;
    private final double costo;

    public ProductoSimple(String nombre, double costo) {
        this.nombre = nombre;
        this.costo = costo;
    }

    @Override
    public String descripcion() {
        return nombre;
    }

    @Override
    public double precio() {
        return costo;
    }

    @Override
    public void mostrar(String sangria) {
        System.out.println(sangria + "- " + nombre + " (S/" + String.format(java.util.Locale.US, "%.2f", costo) + ")");
    }
}

// 3. COMPOSITE (Kit de herramientas o productos)
class Kit implements ArticuloVenta {
    private final String nombre;
    private final List<ArticuloVenta> elementos = new ArrayList<>();

    public Kit(String nombre) {
        this.nombre = nombre;
    }

    public void agregar(ArticuloVenta articulo) {
        elementos.add(articulo);
    }

    @Override
    public String descripcion() {
        StringBuilder sb = new StringBuilder(nombre + " [Kit: ");
        for (int i = 0; i < elementos.size(); i++) {
            sb.append(elementos.get(i).descripcion());
            if (i < elementos.size() - 1) sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }

    @Override
    public double precio() {
        double total = 0;
        for (ArticuloVenta articulo : elementos) {
            total += articulo.precio();
        }
        return total;
    }

    @Override
    public void mostrar(String sangria) {
        System.out.println(sangria + "+ " + nombre + "/ [Total Kit: S/" + String.format(java.util.Locale.US, "%.2f", precio()) + "]");
        for (ArticuloVenta articulo : elementos) {
            articulo.mostrar(sangria + "  ");
        }
    }
}

// 4. DECORATOR (Clase abstracta base para los servicios adicionales)
abstract class ServicioDecorador implements ArticuloVenta {
    protected final ArticuloVenta articuloBase;

    protected ServicioDecorador(ArticuloVenta articuloBase) {
        this.articuloBase = articuloBase;
    }

    @Override
    public String descripcion() {
        return articuloBase.descripcion();
    }

    @Override
    public double precio() {
        return articuloBase.precio();
    }

    @Override
    public void mostrar(String sangria) {
        articuloBase.mostrar(sangria);
    }
}

// 5. CONCRETE DECORATOR (Servicio de Entrega a Domicilio)
class EntregaDomicilio extends ServicioDecorador {
    private final double costoEnvio;

    public EntregaDomicilio(ArticuloVenta articuloBase, double costoEnvio) {
        super(articuloBase);
        this.costoEnvio = costoEnvio;
    }

    @Override
    public String descripcion() {
        return super.descripcion() + " + Entrega a Domicilio";
    }

    @Override
    public double precio() {
        return super.precio() + costoEnvio;
    }

    @Override
    public void mostrar(String sangria) {
        super.mostrar(sangria);
        System.out.println(sangria + "  ↳ Servicio: Entrega a Domicilio (S/" + String.format(java.util.Locale.US, "%.2f", costoEnvio) + ")");
    }
}

// 6. CONCRETE DECORATOR (Servicio de Garantía Extendida)
class GarantiaExtendida extends ServicioDecorador {
    private final double costoGarantia;

    public GarantiaExtendida(ArticuloVenta articuloBase, double costoGarantia) {
        super(articuloBase);
        this.costoGarantia = costoGarantia;
    }

    @Override
    public String descripcion() {
        return super.descripcion() + " + Garantía Extendida";
    }

    @Override
    public double precio() {
        return super.precio() + costoGarantia;
    }

    @Override
    public void mostrar(String sangria) {
        super.mostrar(sangria);
        System.out.println(sangria + "  ↳ Servicio: Garantía Extendida (S/" + String.format(java.util.Locale.US, "%.2f", costoGarantia) + ")");
    }
}