public class MainFerreteria {
    public static void main(String[] args) {
        // Creamos productos individuales (Hojas)
        ArticuloVenta martillo = new ProductoSimple("Martillo de acero", 45.00);
        ArticuloVenta destornillador = new ProductoSimple("Destornillador Phillips", 15.00);
        ArticuloVenta taladro = new ProductoSimple("Taladro percutor", 180.00);
        ArticuloVenta cajaTornillos = new ProductoSimple("Caja de tornillos 100u", 12.50);

        // Creamos un sub-kit de herramientas básicas (Compuesto)
        Kit kitBasico = new Kit("Kit Básico de Mano");
        kitBasico.agregar(martillo);
        kitBasico.agregar(destornillador);

        // Creamos un kit principal que contiene productos sueltos y el sub-kit (Estructura de árbol)
        Kit kitMaster = new Kit("Kit Maestro de Construcción");
        kitMaster.agregar(kitBasico);
        kitMaster.agregar(taladro);
        kitMaster.agregar(cajaTornillos);

        // Aplicamos el patrón Decorator para añadir servicios adicionales dinámicamente
        ArticuloVenta pedidoFinal = kitMaster;
        pedidoFinal = new EntregaDomicilio(pedidoFinal, 20.00);       // Costo de envío
        pedidoFinal = new GarantiaExtendida(pedidoFinal, 35.00);    // Garantía extendida

        // Mostramos la composición completa del pedido y su importe final
        System.out.println("=== DETALLE DEL PEDIDO EN FERRETERÍA 'CONSTRUYE FÁCIL' ===");
        pedidoFinal.mostrar("");

        System.out.println("\n-----------------------------------------------------------");
        System.out.println("Descripción final: " + pedidoFinal.descripcion());
        System.out.printf(java.util.Locale.US, "IMPORTE TOTAL A PAGAR: S/%.2f%n", pedidoFinal.precio());
    }
}