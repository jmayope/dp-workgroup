package pe.edu.ferreteria.app;

import pe.edu.ferreteria.adapter.PasarelaPagoLegacyAdapter;
import pe.edu.ferreteria.adapter.ProveedorLegacyAdapter;
import pe.edu.ferreteria.adapter.ReniecAdapter;
import pe.edu.ferreteria.facade.ComprasFacade;
import pe.edu.ferreteria.facade.InventarioFacade;
import pe.edu.ferreteria.facade.VentaFacade;
import pe.edu.ferreteria.model.Categoria;
import pe.edu.ferreteria.model.Cliente;
import pe.edu.ferreteria.model.DetalleVenta;
import pe.edu.ferreteria.model.DatosReniec;
import pe.edu.ferreteria.model.Producto;
import pe.edu.ferreteria.model.Proveedor;
import pe.edu.ferreteria.model.Venta;
import pe.edu.ferreteria.service.Inventario;
import pe.edu.ferreteria.service.ReporteVentas;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FerreteriaApp {

    public static void main(String[] args) {

        System.out.println("======================================");
        System.out.println("       SISTEMA DE FERRETERÍA");
        System.out.println("  Patrones: Adapter y Facade");
        System.out.println("======================================");

        // =====================================================
        // 1. CREACIÓN DE CATEGORÍA Y PRODUCTOS
        // =====================================================

        Categoria categoria = new Categoria(
                1,
                "Herramientas",
                "Herramientas manuales y eléctricas"
        );

        Producto martillo = new Producto(
                "P-100",
                "Martillo",
                35.90
        );

        Producto taladro = new Producto(
                "P-200",
                "Taladro",
                249.90
        );

        // =====================================================
        // 2. CONSULTA DEL CLIENTE MEDIANTE RENIEC
        // =====================================================

        Scanner scanner = new Scanner(System.in);

        System.out.println("\n--- CONSULTA RENIEC ---");

        System.out.print("Ingrese el DNI del cliente: ");

        String dni = scanner.nextLine();

        ReniecAdapter reniecAdapter =
                new ReniecAdapter();

        Cliente cliente;

        try {

            DatosReniec datosReniec =
                    reniecAdapter.consultarCliente(dni);

            cliente = new Cliente(
                    datosReniec.getDni(),
                    datosReniec.getNombres(),
                    datosReniec.getApellidoPaterno(),
                    datosReniec.getApellidoMaterno()
            );

            System.out.println(
                    "\n--- CLIENTE OBTENIDO DE RENIEC ---"
            );

            System.out.println(
                    "DNI: " + cliente.getDni()
            );

            System.out.println(
                    "Nombres: " + cliente.getNombres()
            );

            System.out.println(
                    "Apellido paterno: "
                            + cliente.getApellidoPaterno()
            );

            System.out.println(
                    "Apellido materno: "
                            + cliente.getApellidoMaterno()
            );

        } catch (Exception e) {

            System.out.println(
                    "\nERROR AL CONSULTAR RENIEC:"
            );

            System.out.println(
                    e.getMessage()
            );

            scanner.close();

            return;
        }

        // =====================================================
        // 3. PROVEEDOR
        // =====================================================

        Proveedor proveedor = new Proveedor(
                "PR-001",
                "20123456789",
                "Proveedor ABC SAC",
                true
        );

        // =====================================================
        // 4. INVENTARIO
        // =====================================================

        Inventario inventario =
                new Inventario();

        InventarioFacade inventarioFacade =
                new InventarioFacade(inventario);

        inventarioFacade.registrarProducto(
                martillo,
                10
        );

        inventarioFacade.registrarProducto(
                taladro,
                5
        );

        System.out.println("\n--- INVENTARIO ---");

        System.out.println(
                "Stock P-100: "
                        + inventario.consultarStock("P-100")
        );

        System.out.println(
                "Stock P-200: "
                        + inventario.consultarStock("P-200")
        );

        // =====================================================
        // 5. ADAPTER PROVEEDOR
        // =====================================================

        System.out.println("\n--- ADAPTER PROVEEDOR ---");

        ProveedorLegacyAdapter proveedorAdapter =
                new ProveedorLegacyAdapter();

        int stockProveedor =
                proveedorAdapter.consultarStock("P-100");

        System.out.println(
                "Stock externo P-100: "
                        + stockProveedor
        );

        // =====================================================
        // 6. ADAPTER + FACADE PARA VENTA
        // =====================================================

        System.out.println("\n--- ADAPTER + FACADE VENTA ---");

        PasarelaPagoLegacyAdapter pagoAdapter =
                new PasarelaPagoLegacyAdapter();

        VentaFacade ventaFacade =
                new VentaFacade(
                        inventario,
                        pagoAdapter
                );

        List<DetalleVenta> items =
                new ArrayList<>();

        items.add(
                new DetalleVenta(
                        martillo,
                        2
                )
        );

        boolean ventaOk =
                ventaFacade.procesarVenta(
                        cliente,
                        items,
                        "TARJETA",
                        true,
                        "Av. Lima 123"
                );

        System.out.println(
                "Resultado venta: "
                        + ventaOk
        );

        // =====================================================
        // 7. FACADE DE COMPRAS
        // =====================================================

        System.out.println("\n--- FACADE COMPRAS ---");

        ComprasFacade comprasFacade =
                new ComprasFacade(inventario);

        boolean reposicion =
                comprasFacade.reponerProducto(
                        proveedor,
                        martillo,
                        5
                );

        System.out.println(
                "Resultado reposición: "
                        + reposicion
        );

        // =====================================================
        // 8. FACADE DE INVENTARIO
        // =====================================================

        System.out.println("\n--- FACADE INVENTARIO ---");

        System.out.println(
                "Disponible P-100 (2): "
                        + inventarioFacade
                        .consultarDisponibilidad(
                                "P-100",
                                2
                        )
        );

        System.out.println(
                "Stock final P-100: "
                        + inventario.consultarStock("P-100")
        );

        // =====================================================
        // 9. REPORTE DE VENTAS
        // =====================================================

        System.out.println("\n--- REPORTE DE VENTAS ---");

        Venta ventaReporte =
                new Venta(
                        100,
                        cliente
                );

        ventaReporte.agregarDetalle(
                new DetalleVenta(
                        taladro,
                        1
                )
        );

        List<Venta> ventas =
                new ArrayList<>();

        ventas.add(
                ventaReporte
        );

        ReporteVentas reporte =
                new ReporteVentas();

        System.out.printf(
                "Total vendido: S/ %.2f%n",
                reporte.totalVendido(ventas)
        );

        System.out.println(
                "Número de ventas: "
                        + reporte.numeroVentas(ventas)
        );

        System.out.printf(
                "Ticket promedio: S/ %.2f%n",
                reporte.ticketPromedio(ventas)
        );

        // =====================================================
        // 10. FINAL
        // =====================================================

        scanner.close();

        System.out.println(
                "\n======================================"
        );

        System.out.println(
                "          FIN DEL PROGRAMA"
        );

        System.out.println(
                "======================================"
        );
    }
}