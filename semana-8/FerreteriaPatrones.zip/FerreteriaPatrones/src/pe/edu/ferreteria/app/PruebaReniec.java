package pe.edu.ferreteria.app;

import pe.edu.ferreteria.adapter.ReniecAdapter;
import pe.edu.ferreteria.model.DatosReniec;

import java.util.Scanner;

public class PruebaReniec {

    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println("       PRUEBA API RENIEC");
        System.out.println("================================");

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese su DNI: ");
        String dni = scanner.nextLine();

        ReniecAdapter reniecAdapter = new ReniecAdapter();

        try {

            DatosReniec datos =
                    reniecAdapter.consultarCliente(dni);

            System.out.println("\n================================");
            System.out.println("       DATOS ENCONTRADOS");
            System.out.println("================================");

            System.out.println("DNI: "
                    + datos.getDni());

            System.out.println("Nombres: "
                    + datos.getNombres());

            System.out.println("Apellido paterno: "
                    + datos.getApellidoPaterno());

            System.out.println("Apellido materno: "
                    + datos.getApellidoMaterno());

        } catch (Exception e) {

            System.out.println("\nERROR:");
            System.out.println(e.getMessage());
        }

        scanner.close();
    }
}