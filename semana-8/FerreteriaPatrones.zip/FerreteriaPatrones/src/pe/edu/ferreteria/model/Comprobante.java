package pe.edu.ferreteria.model;

import java.time.LocalDateTime;

public class Comprobante {
    private final String numero;
    private final String tipo;
    private final LocalDateTime fecha;
    private final double total;

    public Comprobante(String numero, String tipo,
                       double total) {
        this.numero = numero;
        this.tipo = tipo;
        this.fecha = LocalDateTime.now();
        this.total = total;
    }

    public String getNumero() { return numero; }
    public String getTipo() { return tipo; }
    public LocalDateTime getFecha() { return fecha; }
    public double getTotal() { return total; }

    @Override
    public String toString() {
        return tipo + " " + numero + " - S/ "
                + String.format("%.2f", total);
    }
}
