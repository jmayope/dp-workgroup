package pe.edu.ferreteria.model;

public class DatosReniec {

    private final String dni;
    private final String nombres;
    private final String apellidoPaterno;
    private final String apellidoMaterno;

    public DatosReniec(
            String dni,
            String nombres,
            String apellidoPaterno,
            String apellidoMaterno) {

        this.dni = dni;
        this.nombres = nombres;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getDni() {
        return dni;
    }

    public String getNombres() {
        return nombres;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    @Override
    public String toString() {
        return "DNI: " + dni
                + "\nNombres: " + nombres
                + "\nApellido paterno: " + apellidoPaterno
                + "\nApellido materno: " + apellidoMaterno;
    }
}