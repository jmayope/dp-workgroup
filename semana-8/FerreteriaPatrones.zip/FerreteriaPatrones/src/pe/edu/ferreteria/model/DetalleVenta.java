package pe.edu.ferreteria.model;

public class DetalleVenta {
    private final Producto producto;
    private final int cantidad;
    private final double precioUnitario;

    public DetalleVenta(Producto producto, int cantidad) {
        if (producto == null)
            throw new IllegalArgumentException("Producto requerido");
        if (cantidad <= 0)
            throw new IllegalArgumentException("Cantidad inválida");

        this.producto = producto;
        this.cantidad = cantidad;
        this.precioUnitario = producto.getPrecio();
    }

    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }

    public double subtotal() {
        return cantidad * precioUnitario;
    }
}
