package pe.edu.ferreteria.model;

public class Empleado {
    private final String codigo;
    private final String nombre;
    private final String cargo;

    public Empleado(String codigo, String nombre, String cargo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.cargo = cargo;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getCargo() { return cargo; }

    @Override
    public String toString() {
        return codigo + " - " + nombre + " - " + cargo;
    }
}


