package pe.edu.ferreteria.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PedidoCompra {
    private final int id;
    private final Proveedor proveedor;
    private String estado;
    private final List<DetallePedidoCompra> detalles =
            new ArrayList<>();

    public PedidoCompra(int id, Proveedor proveedor) {
        if (proveedor == null)
            throw new IllegalArgumentException("Proveedor requerido");

        this.id = id;
        this.proveedor = proveedor;
        this.estado = "CREADO";
    }

    public void agregarDetalle(DetallePedidoCompra detalle) {
        if (detalle == null)
            throw new IllegalArgumentException("Detalle requerido");
        detalles.add(detalle);
    }

    public double calcularTotal() {
        return detalles.stream()
                .mapToDouble(DetallePedidoCompra::subtotal)
                .sum();
    }

    public int getId() { return id; }
    public Proveedor getProveedor() { return proveedor; }
    public String getEstado() { return estado; }
    public List<DetallePedidoCompra> getDetalles() {
        return Collections.unmodifiableList(detalles);
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
