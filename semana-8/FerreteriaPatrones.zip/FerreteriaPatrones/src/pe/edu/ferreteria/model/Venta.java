package pe.edu.ferreteria.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Venta {

    private final int id;
    private final Cliente cliente;

    private final List<Producto> productos =
            new ArrayList<>();

    private final List<DetalleVenta> detalles =
            new ArrayList<>();

    public Venta(int id, Cliente cliente) {

        if (cliente == null) {
            throw new IllegalArgumentException(
                    "Cliente requerido"
            );
        }

        this.id = id;
        this.cliente = cliente;
    }

    public void agregarProducto(Producto producto) {

        if (producto == null) {
            throw new IllegalArgumentException(
                    "Producto requerido"
            );
        }

        productos.add(producto);

        detalles.add(
                new DetalleVenta(producto, 1)
        );
    }

    public void agregarDetalle(DetalleVenta detalle) {

        if (detalle == null) {
            throw new IllegalArgumentException(
                    "Detalle requerido"
            );
        }

        detalles.add(detalle);
        productos.add(detalle.getProducto());
    }

    public double calcularTotal() {

        return detalles.stream()
                .mapToDouble(DetalleVenta::subtotal)
                .sum();
    }

    public int getId() {
        return id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public List<Producto> getProductos() {
        return Collections.unmodifiableList(productos);
    }

    public List<DetalleVenta> getDetalles() {
        return Collections.unmodifiableList(detalles);
    }
}