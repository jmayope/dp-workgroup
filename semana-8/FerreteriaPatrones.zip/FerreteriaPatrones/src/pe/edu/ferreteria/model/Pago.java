package pe.edu.ferreteria.model;

public class Pago {

    public interface ProcesadorPago {
        boolean pagar(double monto);
    }

    private final int id;
    private final double monto;
    private final String medio;
    private String estado;

    public Pago(int id, double monto, String medio) {
        this.id = id;
        this.monto = monto;
        this.medio = medio;
        this.estado = "PENDIENTE";
    }

    public int getId() {
        return id;
    }

    public double getMonto() {
        return monto;
    }

    public String getMedio() {
        return medio;
    }

    public String getEstado() {
        return estado;
    }

    public void aprobar() {
        estado = "APROBADO";
    }

    public void rechazar() {
        estado = "RECHAZADO";
    }
}