package pe.edu.ferreteria.model;

public class DetallePedidoCompra {
    private final Producto producto;
    private final int cantidad;
    private final double costoUnitario;

    public DetallePedidoCompra(Producto producto,
                               int cantidad,
                               double costoUnitario) {
        if (producto == null)
            throw new IllegalArgumentException("Producto requerido");
        if (cantidad <= 0)
            throw new IllegalArgumentException("Cantidad inválida");
        if (costoUnitario < 0)
            throw new IllegalArgumentException("Costo inválido");

        this.producto = producto;
        this.cantidad = cantidad;
        this.costoUnitario = costoUnitario;
    }

    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public double getCostoUnitario() { return costoUnitario; }

    public double subtotal() {
        return cantidad * costoUnitario;
    }
}
