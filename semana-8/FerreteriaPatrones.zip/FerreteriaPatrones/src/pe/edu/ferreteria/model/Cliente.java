package pe.edu.ferreteria.model;

public class Cliente {

    private String dni;
    private String nombres;
    private String apellidoPaterno;
    private String apellidoMaterno;

    public Cliente(
            String dni,
            String nombres,
            String apellidoPaterno,
            String apellidoMaterno) {

        this.dni = dni;
        this.nombres = nombres;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getDni() {
        return dni;
    }

    public String getNombres() {
        return nombres;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public String getNombreCompleto() {

        return nombres + " "
                + apellidoPaterno + " "
                + apellidoMaterno;
    }

    @Override
    public String toString() {

        return "DNI: " + dni
                + "\nNombres: " + nombres
                + "\nApellido paterno: " + apellidoPaterno
                + "\nApellido materno: " + apellidoMaterno;
    }
}