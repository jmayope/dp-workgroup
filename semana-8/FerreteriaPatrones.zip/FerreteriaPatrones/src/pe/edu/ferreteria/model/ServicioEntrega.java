package pe.edu.ferreteria.model;

public class ServicioEntrega {
    private final int id;
    private final String direccion;
    private final double costo;
    private String estado;

    public ServicioEntrega(int id, String direccion, double costo) {
        this.id = id;
        this.direccion = direccion;
        this.costo = costo;
        this.estado = "PROGRAMADA";
    }

    public void marcarDespachada() {
        estado = "DESPACHADA";
    }

    public void marcarEntregada() {
        estado = "ENTREGADA";
    }

    public int getId() { return id; }
    public String getDireccion() { return direccion; }
    public double getCosto() { return costo; }
    public String getEstado() { return estado; }
}
