package pe.edu.ferreteria.model;

public class Producto {

    private final String codigo;
    private final String nombre;
    private final double precio;

    public Producto(String codigo, String nombre, double precio) {

        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("Código requerido");
        }

        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("Nombre requerido");
        }

        if (precio < 0) {
            throw new IllegalArgumentException("Precio inválido");
        }

        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    @Override
    public String toString() {
        return codigo + " - "
                + nombre + " - S/ "
                + String.format("%.2f", precio);
    }
}