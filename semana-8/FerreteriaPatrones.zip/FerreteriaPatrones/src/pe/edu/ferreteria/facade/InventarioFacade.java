package pe.edu.ferreteria.facade;

import pe.edu.ferreteria.model.Producto;
import pe.edu.ferreteria.service.Inventario;

public class InventarioFacade {
    private final Inventario inventario;

    public InventarioFacade(Inventario inventario) {
        this.inventario = inventario;
    }

    public void registrarProducto(
            Producto producto, int cantidadInicial) {

        if (producto == null)
            throw new IllegalArgumentException("Producto requerido");

        inventario.registrarProducto(producto, cantidadInicial);
    }

    public boolean consultarDisponibilidad(
            String codigo, int cantidad) {

        return inventario.hayStock(codigo, cantidad);
    }

    public void ingresarStock(String codigo, int cantidad) {
        inventario.ingresar(codigo, cantidad);
    }

    public void retirarStock(String codigo, int cantidad) {
        inventario.retirar(codigo, cantidad);
    }
}
