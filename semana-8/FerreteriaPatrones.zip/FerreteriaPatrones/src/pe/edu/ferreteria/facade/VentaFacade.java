package pe.edu.ferreteria.facade;

import pe.edu.ferreteria.adapter.PasarelaPagoLegacyAdapter;
import pe.edu.ferreteria.model.Cliente;
import pe.edu.ferreteria.model.Comprobante;
import pe.edu.ferreteria.model.DetalleVenta;
import pe.edu.ferreteria.model.Pago;
import pe.edu.ferreteria.model.ServicioEntrega;
import pe.edu.ferreteria.model.Venta;
import pe.edu.ferreteria.service.Inventario;

import java.util.List;

public class VentaFacade {

    private final Inventario inventario;

    private final Pago.ProcesadorPago procesadorPago;

    private int siguienteVenta = 1;
    private int siguientePago = 1;
    private int siguienteComprobante = 1;
    private int siguienteEntrega = 1;

    public VentaFacade(
            Inventario inventario,
            Pago.ProcesadorPago procesadorPago) {

        this.inventario = inventario;
        this.procesadorPago = procesadorPago;
    }

    public boolean procesarVenta(
            Cliente cliente,
            List<DetalleVenta> items,
            String medioPago,
            boolean requiereEntrega,
            String direccionEntrega) {

        // 1. Validar datos
        if (cliente == null ||
                items == null ||
                items.isEmpty()) {

            System.out.println(
                    "Datos de venta inválidos."
            );

            return false;
        }

        // 2. Verificar stock
        for (DetalleVenta item : items) {

            String codigo =
                    item.getProducto().getCodigo();

            int cantidad =
                    item.getCantidad();

            if (!inventario.hayStock(
                    codigo,
                    cantidad)) {

                System.out.println(
                        "Stock insuficiente: "
                                + item.getProducto().getNombre()
                );

                return false;
            }
        }

        // 3. Crear venta
        Venta venta =
                new Venta(
                        siguienteVenta++,
                        cliente
                );

        for (DetalleVenta item : items) {
            venta.agregarDetalle(item);
        }

        double total =
                venta.calcularTotal();

        // 4. Crear pago
        Pago pago =
                new Pago(
                        siguientePago++,
                        total,
                        medioPago
                );

        // 5. Procesar pago mediante Adapter
        boolean aprobado =
                procesadorPago.pagar(total);

        if (!aprobado) {

            pago.rechazar();

            System.out.println(
                    "Pago rechazado."
            );

            return false;
        }

        pago.aprobar();

        System.out.println(
                "Pago: "
                        + pago.getEstado()
        );

        // 6. Retirar stock
        for (DetalleVenta item : items) {

            inventario.retirar(
                    item.getProducto().getCodigo(),
                    item.getCantidad()
            );
        }

        // 7. Crear comprobante
        Comprobante comprobante =
                new Comprobante(
                        "B001-"
                                + String.format(
                                "%06d",
                                siguienteComprobante++
                        ),
                        "BOLETA",
                        total
                );

        System.out.println(
                "Comprobante: "
                        + comprobante
        );

        // 8. Programar entrega
        if (requiereEntrega) {

            ServicioEntrega entrega =
                    new ServicioEntrega(
                            siguienteEntrega++,
                            direccionEntrega,
                            10.00
                    );

            System.out.println(
                    "Entrega programada: "
                            + entrega.getDireccion()
            );
        }

        System.out.println(
                "Venta "
                        + venta.getId()
                        + " procesada correctamente."
        );

        return true;
    }
}