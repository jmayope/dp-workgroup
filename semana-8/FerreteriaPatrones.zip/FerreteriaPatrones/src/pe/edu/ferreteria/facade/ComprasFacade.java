package pe.edu.ferreteria.facade;

import pe.edu.ferreteria.model.DetallePedidoCompra;
import pe.edu.ferreteria.model.PedidoCompra;
import pe.edu.ferreteria.model.Producto;
import pe.edu.ferreteria.model.Proveedor;
import pe.edu.ferreteria.service.Inventario;

public class ComprasFacade {

    private final Inventario inventario;

    private int siguientePedido = 1;

    public ComprasFacade(Inventario inventario) {
        this.inventario = inventario;
    }

    public boolean reponerProducto(
            Proveedor proveedor,
            Producto producto,
            int cantidad) {

        // Validar proveedor
        if (proveedor == null ||
                !proveedor.isActivo()) {

            System.out.println(
                    "Proveedor inválido o inactivo."
            );

            return false;
        }

        // Validar producto
        if (producto == null ||
                cantidad <= 0) {

            System.out.println(
                    "Producto o cantidad inválida."
            );

            return false;
        }

        // Crear pedido
        PedidoCompra pedido =
                new PedidoCompra(
                        siguientePedido++,
                        proveedor
                );

        // Simular costo de compra
        double costoUnitario =
                producto.getPrecio() * 0.70;

        // Crear detalle
        DetallePedidoCompra detalle =
                new DetallePedidoCompra(
                        producto,
                        cantidad,
                        costoUnitario
                );

        pedido.agregarDetalle(detalle);

        // Cambiar estado
        pedido.setEstado("RECIBIDO");

        // Actualizar inventario
        inventario.ingresar(
                producto.getCodigo(),
                cantidad
        );

        System.out.printf(
                "Pedido %d recibido. Total: S/ %.2f%n",
                pedido.getId(),
                pedido.calcularTotal()
        );

        return true;
    }
}