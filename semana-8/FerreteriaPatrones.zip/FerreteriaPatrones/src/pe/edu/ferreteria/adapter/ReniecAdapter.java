package pe.edu.ferreteria.adapter;

import pe.edu.ferreteria.model.DatosReniec;
import pe.edu.ferreteria.service.ReniecService;

import java.io.IOException;

public class ReniecAdapter {

    private final ReniecService reniecService;

    public ReniecAdapter() {
        this.reniecService =
                new ReniecService();
    }

    public DatosReniec consultarCliente(
            String dni) {

        try {

            return reniecService.consultarDni(
                    dni
            );

        } catch (IOException |
                 InterruptedException e) {

            Thread.currentThread()
                    .interrupt();

            throw new RuntimeException(
                    "Error al consultar RENIEC: "
                            + e.getMessage(),
                    e
            );
        }
    }
}