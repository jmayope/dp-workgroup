package pe.edu.ferreteria.adapter;

import pe.edu.ferreteria.model.Pago;

public class PasarelaPagoLegacyAdapter
        implements Pago.ProcesadorPago {

    private static class PasarelaPagoLegacy {

        public boolean cobrar(double monto, String moneda) {
            System.out.println(
                    "Pasarela LEGACY: cobrando "
                            + monto + " " + moneda
            );

            return monto > 0;
        }
    }

    private final PasarelaPagoLegacy legacy;

    public PasarelaPagoLegacyAdapter() {
        this.legacy = new PasarelaPagoLegacy();
    }

    @Override
    public boolean pagar(double monto) {
        return legacy.cobrar(monto, "PEN");
    }
}