package pe.edu.ferreteria.adapter;

import pe.edu.ferreteria.model.Proveedor;

public class ProveedorLegacyAdapter
        implements Proveedor.CatalogoProveedor {

    private static class ProveedorAntiguo {

        public int existencias(int idExterno) {

            if (idExterno == 100) {
                return 40;
            }

            if (idExterno == 200) {
                return 15;
            }

            return 0;
        }
    }

    private final ProveedorAntiguo proveedor;

    public ProveedorLegacyAdapter() {
        this.proveedor = new ProveedorAntiguo();
    }

    @Override
    public int consultarStock(String codigo) {

        if (codigo == null || !codigo.startsWith("P-")) {
            throw new IllegalArgumentException(
                    "Código esperado: P-100"
            );
        }

        int idExterno =
                Integer.parseInt(
                        codigo.replace("P-", "")
                );

        return proveedor.existencias(idExterno);
    }
}