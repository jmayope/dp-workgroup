package pe.edu.ferreteria.service;

import pe.edu.ferreteria.model.Venta;
import java.util.Collection;

public class ReporteVentas {

    public double totalVendido(Collection<Venta> ventas) {
        return ventas.stream()
                .mapToDouble(Venta::calcularTotal)
                .sum();
    }

    public int numeroVentas(Collection<Venta> ventas) {
        return ventas.size();
    }

    public double ticketPromedio(Collection<Venta> ventas) {
        if (ventas.isEmpty()) return 0.0;
        return totalVendido(ventas) / ventas.size();
    }
}
