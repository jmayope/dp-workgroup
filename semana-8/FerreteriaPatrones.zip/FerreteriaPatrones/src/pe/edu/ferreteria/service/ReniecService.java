package pe.edu.ferreteria.service;

import pe.edu.ferreteria.model.DatosReniec;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReniecService {

    /*
     * Endpoint indicado en el documento del docente.
     */
    private static final String API_URL =
            "https://api.apis.net.pe/v2/reniec/dni?numero=";

    private final HttpClient httpClient;

    public ReniecService() {
        this.httpClient = HttpClient.newHttpClient();
    }

    public DatosReniec consultarDni(String dni)
            throws IOException, InterruptedException {

        validarDni(dni);

        String token =
                System.getenv("RENIEC_TOKEN");

        if (token == null || token.isBlank()) {

            throw new IllegalStateException(
                    "No se encontró la variable de entorno RENIEC_TOKEN."
            );
        }

        String url = API_URL + dni;

        HttpRequest request =
                HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header(
                                "Authorization",
                                "Bearer " + token
                        )
                        .header(
                                "Accept",
                                "application/json"
                        )
                        .GET()
                        .build();

        HttpResponse<String> response =
                httpClient.send(
                        request,
                        HttpResponse.BodyHandlers.ofString()
                );

        int statusCode =
                response.statusCode();

        if (statusCode == 200) {

            return convertirRespuesta(
                    dni,
                    response.body()
            );
        }

        if (statusCode == 404) {

            throw new IllegalArgumentException(
                    "No se encontraron datos para el DNI: "
                            + dni
            );
        }

        if (statusCode == 422) {

            throw new IllegalArgumentException(
                    "El DNI no tiene un formato válido."
            );
        }

        if (statusCode == 401 ||
                statusCode == 403) {

            throw new IllegalStateException(
                    "Token inválido o sin autorización."
            );
        }

        throw new IOException(
                "Error en API RENIEC. Código HTTP: "
                        + statusCode
        );
    }

    private void validarDni(String dni) {

        if (dni == null ||
                !dni.matches("\\d{8}")) {

            throw new IllegalArgumentException(
                    "El DNI debe contener exactamente 8 dígitos."
            );
        }
    }

    private DatosReniec convertirRespuesta(
            String dni,
            String json) {

        String nombres =
                obtenerCampo(
                        json,
                        "nombres"
                );

        String apellidoPaterno =
                obtenerCampo(
                        json,
                        "apellidoPaterno"
                );

        String apellidoMaterno =
                obtenerCampo(
                        json,
                        "apellidoMaterno"
                );

        if (nombres == null ||
                apellidoPaterno == null ||
                apellidoMaterno == null) {

            throw new IllegalStateException(
                    "La respuesta de RENIEC no contiene los datos esperados."
            );
        }

        return new DatosReniec(
                dni,
                nombres,
                apellidoPaterno,
                apellidoMaterno
        );
    }

    private String obtenerCampo(
            String json,
            String campo) {

        String expresion =
                "\"" + campo + "\"\\s*:\\s*\"([^\"]*)\"";

        Pattern pattern =
                Pattern.compile(expresion);

        Matcher matcher =
                pattern.matcher(json);

        if (matcher.find()) {
            return matcher.group(1);
        }

        return null;
    }
}