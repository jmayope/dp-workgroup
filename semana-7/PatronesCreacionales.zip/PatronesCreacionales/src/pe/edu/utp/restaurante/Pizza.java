package pe.edu.utp.restaurante;

public class Pizza implements Plato {
    @Override
    public void preparar() {
        System.out.println("Horneando pizza de peperoni...");
    }
}