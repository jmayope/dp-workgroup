package pe.edu.utp.restaurante;

public interface Plato {
    void preparar();
}