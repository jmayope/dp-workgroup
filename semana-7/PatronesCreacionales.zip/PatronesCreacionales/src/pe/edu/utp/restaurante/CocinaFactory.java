package pe.edu.utp.restaurante;

public abstract class CocinaFactory {
    public abstract Plato crearPlato(String tipo);
}