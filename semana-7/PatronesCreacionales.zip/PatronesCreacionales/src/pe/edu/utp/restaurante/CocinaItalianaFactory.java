package pe.edu.utp.restaurante;

public class CocinaItalianaFactory extends CocinaFactory {
    @Override
    public Plato crearPlato(String tipo) {
        if (tipo.equalsIgnoreCase("pizza")) return new Pizza();
        if (tipo.equalsIgnoreCase("pasta")) return new Pasta();
        return null;
    }
}
