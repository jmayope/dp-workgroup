package pe.edu.utp.restaurante;

public class Cerveza implements Bebida {
    @Override
    public void servir() {
        System.out.println("Sirviendo cerveza bien fría...");
    }
}
