package pe.edu.utp.restaurante;

public class MenuItalianoFactory implements MenuFactory {
    @Override
    public Plato crearPlato() {
        return new Pizza();
    }

    @Override
    public Bebida crearBebida() {
        return new Cerveza();
    }
}