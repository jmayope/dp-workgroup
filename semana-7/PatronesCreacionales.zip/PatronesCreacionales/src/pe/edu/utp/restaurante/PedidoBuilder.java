package pe.edu.utp.restaurante;

public class PedidoBuilder {
    private Plato plato;
    private Bebida bebida;

    public PedidoBuilder setPlato(Plato plato) {
        this.plato = plato;
        return this;
    }

    public PedidoBuilder setBebida(Bebida bebida) {
        this.bebida = bebida;
        return this;
    }

    public Pedido build() {
        return new Pedido(plato, bebida);
    }
}
