package pe.edu.utp.restaurante;

public interface MenuFactory {
    Plato crearPlato();
    Bebida crearBebida();
}