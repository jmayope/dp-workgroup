package pe.edu.utp.restaurante;

public class Pasta implements Plato {
    @Override
    public void preparar() {
        System.out.println("Hirviendo pasta al dente con salsa boloñesa...");
    }
}