package pe.edu.utp.restaurante;

public interface Bebida {
    void servir();
}
