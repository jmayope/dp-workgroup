package pe.edu.utp.restaurante;

public class Pedido {
    private Plato plato;
    private Bebida bebida;

    public Pedido(Plato plato, Bebida bebida) {
        this.plato = plato;
        this.bebida = bebida;
    }

    public void imprimirResumen() {
        System.out.println("--- RESUMEN DEL PEDIDO ---");
        if (plato != null) plato.preparar();
        if (bebida != null) bebida.servir();
        System.out.println("Pedido confirmado en cocina.\n");
    }
}