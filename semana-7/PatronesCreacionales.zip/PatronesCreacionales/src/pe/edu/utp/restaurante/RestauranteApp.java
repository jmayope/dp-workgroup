package pe.edu.utp.restaurante;

public class RestauranteApp {
    public static void main(String[] args) {
        System.out.println("=== PROCESANDO PEDIDO CON PATRONES ===");

        // Uso de Abstract Factory y Builder
        MenuFactory menuItaliano = new MenuItalianoFactory();

        Pedido pedido1 = new PedidoBuilder()
                .setPlato(menuItaliano.crearPlato())
                .setBebida(menuItaliano.crearBebida())
                .build();

        pedido1.imprimirResumen();
    }
}
